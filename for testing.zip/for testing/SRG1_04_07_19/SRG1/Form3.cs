﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SRG1
{
    public partial class Form3 : Form
    {
        public static Form3 Form3Instance;
        public Form3()
        {
            Form3Instance = this;
            InitializeComponent();
        }
        
        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'srgDataSet10.type3' table.
             this.type3TableAdapter1.Fill(this.srgDataSet10.type3);
            // TODO: This line of code loads data into the 'srgDataSet9.type3' table.
             this.type3TableAdapter.Fill(this.srgDataSet9.type3);
        }

        private void select_DataToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
               this.type3TableAdapter.Select_Data(this.srgDataSet9.type3, brandToolStripTextBox.Text, tradePartnerToolStripTextBox.Text, distrCentreToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void select_RowToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
               this.type3TableAdapter1.Select_Row(this.srgDataSet10.type3, brandToolStripTextBox1.Text, trade_PartnerToolStripTextBox.Text, distr_CentreToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Close();
            
        }
    }   
}
