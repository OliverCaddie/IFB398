﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SRG1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
       // public static string POrg = null;
      //  public static string Vendor = null;
       // public static string Site = null;
       // public static string Article = null;
        private void Form4_Load(object sender, EventArgs e)
        {
           
            // TODO: This line of code loads data into the 'srgDataSet14.type3' table. You can move, or remove it, as needed.
            this.type3TableAdapter.Fill(this.srgDataSet14.type3);

            foreach (DataGridViewColumn dc in dataGridView1.Columns)
            {
                if (dc.Index.Equals(21))
                {
                    dc.ReadOnly = false;
                }
                else
                {
                    dc.ReadOnly = true;
                }
            }
   
        }
        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.type3BindingSource.EndEdit();
                this.type3TableAdapter.Update(srgDataSet14.type3);
                MessageBox.Show("Data Updated!");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.type3TableAdapter.FillBy(this.srgDataSet14.type3, pOrgToolStripTextBox.Text, vendorToolStripTextBox.Text, siteToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}