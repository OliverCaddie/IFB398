﻿

namespace SRG1
{


    partial class srgDataSet14
    {
    }
}

namespace SRG1.srgDataSet14TableAdapters {
    
    
    public partial class type3TableAdapter {
    }
}
