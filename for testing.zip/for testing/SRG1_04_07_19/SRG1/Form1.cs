﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SRG1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            fill_listbox();
        }
        public static string SetDIF = "";
        public static string SetDOT = "";
        public static string SetBrand = "";
        public static string SetTP = "";
        public static string SetDC = "";
        public static string SetSD = "";
        public static string SetED = "";
        public static string SetCat = "";
        public static string SetSCat = "";
        public static string SetArt = "";
        public static string SetPO = "";
        public static string SetPurchOrg = "";
        public static string sVendor = "";
       
        // DECLARE @date1 date = maskedTextBox1.Text;
        // DECLARE @date2 date = maskedTextBox2.Text;
        //public static bool vizibleForm3 = false;
        // public static bool vizibleForm2 = false;

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        void fill_listbox()
        {
            string connectionString;
            SqlConnection cnn;
            connectionString = @"Data Source=localhost;Initial Catalog=srg;Integrated Security=True";
            String sql2 = "SELECT DISTINCT Vendor from dbo.type3;";
            cnn = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(sql2, cnn);
            SqlDataReader dataReader;
            cnn.Open();
            dataReader = command.ExecuteReader();

            try
            {
               while (dataReader.Read())
                {
                    sVendor = dataReader.GetValue(0).ToString();
                    listBox1.Items.Add(sVendor);
                } 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataReader.Close();
            command.Dispose();
            cnn.Close();
        }
            private void DIFOT_Click(object sender, EventArgs e)
        {
            string connectionString;
            SqlConnection cnn;
            connectionString = @"Data Source=localhost;Initial Catalog=srg;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();
            SqlCommand command, command1;
            SqlDataReader dataReader, dataReader1;
            String sql, sql1;

            sql = "SELECT CAST(CAST(SUM(chk) AS FLOAT)/COUNT(chk)*100 AS DECIMAL(5,3)) FROM DIF WHERE 1=1";
                sql1 = "SELECT CAST(CAST(SUM(chk) AS FLOAT)/ COUNT(chk)*100 AS DECIMAL(5,3)) FROM DOT WHERE 1=1";
            if (maskedTextBox1.Text != null && maskedTextBox2.Text != null)
            {
                sql += textBox1.Text != null && textBox1.Text != "" ? " AND brand = '" + textBox1.Text + "'" : "";
                sql += textBox2.Text != null && textBox2.Text != "" ? " AND vendor = '" + textBox2.Text + "'" : "";
                sql += textBox3.Text != null && textBox3.Text != "" ? " AND del_site = '" + textBox3.Text + "'" : "";
                sql += maskedTextBox1.Text != null && maskedTextBox1.Text != "" ? " AND PO_date >= '" + maskedTextBox1.Text + "'" : "";
                sql += maskedTextBox2.Text != null && maskedTextBox2.Text != "" ? " AND PO_date < '" + maskedTextBox2.Text + "'" : "";
                sql += textBox4.Text != null && textBox4.Text != "" ? " AND category = '" + textBox4.Text + "'" : "";
                sql += textBox6.Text != null && textBox6.Text != "" ? " AND subcategory = '" + textBox6.Text + "'" : "";
                sql += textBox8.Text != null && textBox8.Text != "" ? " AND article = '" + textBox8.Text + "'" : "";
                sql += textBox5.Text != null && textBox5.Text != "" ? " AND PO_order = '" + textBox5.Text + "'" : "";


                sql1 += textBox1.Text != null && textBox1.Text != "" ? " AND brand = '" + textBox1.Text + "'" : "";
                sql1 += textBox2.Text != null && textBox2.Text != "" ? " AND vendor = '" + textBox2.Text + "'" : "";
                sql1 += textBox3.Text != null && textBox3.Text != "" ? " AND del_site = '" + textBox3.Text + "'" : "";
                sql1 += maskedTextBox1.Text != null && maskedTextBox1.Text != "" ? " AND PO_date >= '" + maskedTextBox1.Text + "'" : "";
                sql1 += maskedTextBox2.Text != null && maskedTextBox2.Text != "" ? " AND PO_date < '" + maskedTextBox2.Text + "'" : "";
                sql1 += textBox4.Text != null && textBox4.Text != "" ? " AND category = '" + textBox4.Text + "'" : "";
                sql1 += textBox6.Text != null && textBox6.Text != "" ? " AND subcategory = '" + textBox6.Text + "'" : "";
                sql1 += textBox8.Text != null && textBox8.Text != "" ? " AND article = '" + textBox8.Text + "'" : "";
                sql1 += textBox5.Text != null && textBox5.Text != "" ? " AND PO_order = '" + textBox5.Text + "'" : "";

            }
            command = new SqlCommand(sql.ToString(), cnn);
            dataReader = command.ExecuteReader();
            dataReader.Read();
            SetDIF = dataReader.GetValue(0).ToString();   
            dataReader.Close();
            command.Dispose();

            command1 = new SqlCommand(sql1.ToString(), cnn);
            dataReader1 = command1.ExecuteReader();
            dataReader1.Read();
            if (dataReader1.GetValue(0).ToString() == "")
            {
                MessageBox.Show("Record not found or date not valid!");
            }
            else
            { 
                    SetDOT = dataReader1.GetValue(0).ToString();
                    SetBrand = textBox1.Text;
                    SetTP = textBox2.Text;
                    SetDC = textBox3.Text;
                    SetSD = maskedTextBox1.Text;
                    SetED = maskedTextBox2.Text;
                    SetCat = textBox4.Text;
                    SetSCat = textBox6.Text;
                    SetArt = textBox8.Text;
                    SetPO = textBox5.Text;
                    SetPurchOrg = textBox7.Text;

                    dataReader1.Close();
                    command1.Dispose();
                    cnn.Close();
                    Form2 frm2 = new Form2();
                    frm2.Show();             
            }
           // cnn.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
            maskedTextBox1.Text = string.Empty;
            textBox6.Text = string.Empty;
            maskedTextBox2.Text = string.Empty;
            textBox8.Text = string.Empty;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.Show();
        }
    }
}

