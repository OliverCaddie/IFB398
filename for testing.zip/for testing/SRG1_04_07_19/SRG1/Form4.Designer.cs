﻿namespace SRG1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.pOrgToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.pOrgToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.vendorToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.vendorToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.siteToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.siteToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.type3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.srgDataSet14 = new SRG1.srgDataSet14();
            this.purchDocDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pOrgDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mdseCatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorArticleNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pOQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.netPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dCIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.delivDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statDelDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pstngDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entryDteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scheduledQtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDeliveredDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pKeyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.includeValueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.type3TableAdapter = new SRG1.srgDataSet14TableAdapters.type3TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.fillByToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.type3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.srgDataSet14)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.purchDocDataGridViewTextBoxColumn,
            this.pOrgDataGridViewTextBoxColumn,
            this.docDateDataGridViewTextBoxColumn,
            this.vendorDataGridViewTextBoxColumn,
            this.siteDataGridViewTextBoxColumn,
            this.itemDataGridViewTextBoxColumn,
            this.articleDataGridViewTextBoxColumn,
            this.mdseCatDataGridViewTextBoxColumn,
            this.vendorArticleNumberDataGridViewTextBoxColumn,
            this.pOQuantityDataGridViewTextBoxColumn,
            this.netPriceDataGridViewTextBoxColumn,
            this.dDataGridViewTextBoxColumn,
            this.dCIDataGridViewTextBoxColumn,
            this.delivDateDataGridViewTextBoxColumn,
            this.statDelDDataGridViewTextBoxColumn,
            this.pstngDateDataGridViewTextBoxColumn,
            this.entryDteDataGridViewTextBoxColumn,
            this.scheduledQtyDataGridViewTextBoxColumn,
            this.qtyDeliveredDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.pKeyDataGridViewTextBoxColumn,
            this.includeValueDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.type3BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, 91);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1416, 607);
            this.dataGridView1.TabIndex = 0;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.BindingSource = this.type3BindingSource;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.toolStripButton1});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(1477, 33);
            this.bindingNavigator1.TabIndex = 1;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(54, 28);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 33);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 31);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::SRG1.Properties.Resources.edit;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton1.Text = "Update Data";
            this.toolStripButton1.Click += new System.EventHandler(this.ToolStripButton1_Click);
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pOrgToolStripLabel,
            this.pOrgToolStripTextBox,
            this.vendorToolStripLabel,
            this.vendorToolStripTextBox,
            this.siteToolStripLabel,
            this.siteToolStripTextBox,
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 33);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(1477, 34);
            this.fillByToolStrip.TabIndex = 13;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // pOrgToolStripLabel
            // 
            this.pOrgToolStripLabel.Name = "pOrgToolStripLabel";
            this.pOrgToolStripLabel.Size = new System.Drawing.Size(57, 29);
            this.pOrgToolStripLabel.Text = "POrg:";
            // 
            // pOrgToolStripTextBox
            // 
            this.pOrgToolStripTextBox.Name = "pOrgToolStripTextBox";
            this.pOrgToolStripTextBox.Size = new System.Drawing.Size(100, 34);
            // 
            // vendorToolStripLabel
            // 
            this.vendorToolStripLabel.Name = "vendorToolStripLabel";
            this.vendorToolStripLabel.Size = new System.Drawing.Size(73, 29);
            this.vendorToolStripLabel.Text = "Vendor:";
            // 
            // vendorToolStripTextBox
            // 
            this.vendorToolStripTextBox.Name = "vendorToolStripTextBox";
            this.vendorToolStripTextBox.Size = new System.Drawing.Size(100, 34);
            // 
            // siteToolStripLabel
            // 
            this.siteToolStripLabel.Name = "siteToolStripLabel";
            this.siteToolStripLabel.Size = new System.Drawing.Size(45, 29);
            this.siteToolStripLabel.Text = "Site:";
            // 
            // siteToolStripTextBox
            // 
            this.siteToolStripTextBox.Name = "siteToolStripTextBox";
            this.siteToolStripTextBox.Size = new System.Drawing.Size(100, 34);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(54, 29);
            this.fillByToolStripButton.Text = "Filter";
            this.fillByToolStripButton.Click += new System.EventHandler(this.FillByToolStripButton_Click);
            // 
            // type3BindingSource
            // 
            this.type3BindingSource.DataMember = "type3";
            this.type3BindingSource.DataSource = this.srgDataSet14;
            // 
            // srgDataSet14
            // 
            this.srgDataSet14.DataSetName = "srgDataSet14";
            this.srgDataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // purchDocDataGridViewTextBoxColumn
            // 
            this.purchDocDataGridViewTextBoxColumn.DataPropertyName = "Purch_Doc_";
            this.purchDocDataGridViewTextBoxColumn.HeaderText = "Purch_Doc_";
            this.purchDocDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.purchDocDataGridViewTextBoxColumn.Name = "purchDocDataGridViewTextBoxColumn";
            this.purchDocDataGridViewTextBoxColumn.Width = 133;
            // 
            // pOrgDataGridViewTextBoxColumn
            // 
            this.pOrgDataGridViewTextBoxColumn.DataPropertyName = "POrg";
            this.pOrgDataGridViewTextBoxColumn.HeaderText = "POrg";
            this.pOrgDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pOrgDataGridViewTextBoxColumn.Name = "pOrgDataGridViewTextBoxColumn";
            this.pOrgDataGridViewTextBoxColumn.Width = 81;
            // 
            // docDateDataGridViewTextBoxColumn
            // 
            this.docDateDataGridViewTextBoxColumn.DataPropertyName = "Doc__Date";
            this.docDateDataGridViewTextBoxColumn.HeaderText = "Doc__Date";
            this.docDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.docDateDataGridViewTextBoxColumn.Name = "docDateDataGridViewTextBoxColumn";
            this.docDateDataGridViewTextBoxColumn.Width = 127;
            // 
            // vendorDataGridViewTextBoxColumn
            // 
            this.vendorDataGridViewTextBoxColumn.DataPropertyName = "Vendor";
            this.vendorDataGridViewTextBoxColumn.HeaderText = "Vendor";
            this.vendorDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vendorDataGridViewTextBoxColumn.Name = "vendorDataGridViewTextBoxColumn";
            this.vendorDataGridViewTextBoxColumn.Width = 97;
            // 
            // siteDataGridViewTextBoxColumn
            // 
            this.siteDataGridViewTextBoxColumn.DataPropertyName = "Site";
            this.siteDataGridViewTextBoxColumn.HeaderText = "Site";
            this.siteDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.siteDataGridViewTextBoxColumn.Name = "siteDataGridViewTextBoxColumn";
            this.siteDataGridViewTextBoxColumn.Width = 73;
            // 
            // itemDataGridViewTextBoxColumn
            // 
            this.itemDataGridViewTextBoxColumn.DataPropertyName = "Item";
            this.itemDataGridViewTextBoxColumn.HeaderText = "Item";
            this.itemDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.itemDataGridViewTextBoxColumn.Name = "itemDataGridViewTextBoxColumn";
            this.itemDataGridViewTextBoxColumn.Width = 77;
            // 
            // articleDataGridViewTextBoxColumn
            // 
            this.articleDataGridViewTextBoxColumn.DataPropertyName = "Article";
            this.articleDataGridViewTextBoxColumn.HeaderText = "Article";
            this.articleDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.articleDataGridViewTextBoxColumn.Name = "articleDataGridViewTextBoxColumn";
            this.articleDataGridViewTextBoxColumn.Width = 89;
            // 
            // mdseCatDataGridViewTextBoxColumn
            // 
            this.mdseCatDataGridViewTextBoxColumn.DataPropertyName = "Mdse_Cat_";
            this.mdseCatDataGridViewTextBoxColumn.HeaderText = "Mdse_Cat_";
            this.mdseCatDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.mdseCatDataGridViewTextBoxColumn.Name = "mdseCatDataGridViewTextBoxColumn";
            this.mdseCatDataGridViewTextBoxColumn.Width = 127;
            // 
            // vendorArticleNumberDataGridViewTextBoxColumn
            // 
            this.vendorArticleNumberDataGridViewTextBoxColumn.DataPropertyName = "Vendor_Article_Number";
            this.vendorArticleNumberDataGridViewTextBoxColumn.HeaderText = "Vendor_Article_Number";
            this.vendorArticleNumberDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vendorArticleNumberDataGridViewTextBoxColumn.Name = "vendorArticleNumberDataGridViewTextBoxColumn";
            this.vendorArticleNumberDataGridViewTextBoxColumn.Width = 215;
            // 
            // pOQuantityDataGridViewTextBoxColumn
            // 
            this.pOQuantityDataGridViewTextBoxColumn.DataPropertyName = "PO_Quantity";
            this.pOQuantityDataGridViewTextBoxColumn.HeaderText = "PO_Quantity";
            this.pOQuantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pOQuantityDataGridViewTextBoxColumn.Name = "pOQuantityDataGridViewTextBoxColumn";
            this.pOQuantityDataGridViewTextBoxColumn.Width = 135;
            // 
            // netPriceDataGridViewTextBoxColumn
            // 
            this.netPriceDataGridViewTextBoxColumn.DataPropertyName = "Net_Price";
            this.netPriceDataGridViewTextBoxColumn.HeaderText = "Net_Price";
            this.netPriceDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.netPriceDataGridViewTextBoxColumn.Name = "netPriceDataGridViewTextBoxColumn";
            this.netPriceDataGridViewTextBoxColumn.Width = 114;
            // 
            // dDataGridViewTextBoxColumn
            // 
            this.dDataGridViewTextBoxColumn.DataPropertyName = "D";
            this.dDataGridViewTextBoxColumn.HeaderText = "D";
            this.dDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dDataGridViewTextBoxColumn.Name = "dDataGridViewTextBoxColumn";
            this.dDataGridViewTextBoxColumn.Width = 57;
            // 
            // dCIDataGridViewTextBoxColumn
            // 
            this.dCIDataGridViewTextBoxColumn.DataPropertyName = "DCI";
            this.dCIDataGridViewTextBoxColumn.HeaderText = "DCI";
            this.dCIDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dCIDataGridViewTextBoxColumn.Name = "dCIDataGridViewTextBoxColumn";
            this.dCIDataGridViewTextBoxColumn.Width = 73;
            // 
            // delivDateDataGridViewTextBoxColumn
            // 
            this.delivDateDataGridViewTextBoxColumn.DataPropertyName = "Deliv__Date";
            this.delivDateDataGridViewTextBoxColumn.HeaderText = "Deliv__Date";
            this.delivDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.delivDateDataGridViewTextBoxColumn.Name = "delivDateDataGridViewTextBoxColumn";
            this.delivDateDataGridViewTextBoxColumn.Width = 132;
            // 
            // statDelDDataGridViewTextBoxColumn
            // 
            this.statDelDDataGridViewTextBoxColumn.DataPropertyName = "StatDelD";
            this.statDelDDataGridViewTextBoxColumn.HeaderText = "StatDelD";
            this.statDelDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statDelDDataGridViewTextBoxColumn.Name = "statDelDDataGridViewTextBoxColumn";
            this.statDelDDataGridViewTextBoxColumn.Width = 111;
            // 
            // pstngDateDataGridViewTextBoxColumn
            // 
            this.pstngDateDataGridViewTextBoxColumn.DataPropertyName = "Pstng_Date";
            this.pstngDateDataGridViewTextBoxColumn.HeaderText = "Pstng_Date";
            this.pstngDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pstngDateDataGridViewTextBoxColumn.Name = "pstngDateDataGridViewTextBoxColumn";
            this.pstngDateDataGridViewTextBoxColumn.Width = 130;
            // 
            // entryDteDataGridViewTextBoxColumn
            // 
            this.entryDteDataGridViewTextBoxColumn.DataPropertyName = "Entry_Dte";
            this.entryDteDataGridViewTextBoxColumn.HeaderText = "Entry_Dte";
            this.entryDteDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.entryDteDataGridViewTextBoxColumn.Name = "entryDteDataGridViewTextBoxColumn";
            this.entryDteDataGridViewTextBoxColumn.Width = 117;
            // 
            // scheduledQtyDataGridViewTextBoxColumn
            // 
            this.scheduledQtyDataGridViewTextBoxColumn.DataPropertyName = "Scheduled_Qty";
            this.scheduledQtyDataGridViewTextBoxColumn.HeaderText = "Scheduled_Qty";
            this.scheduledQtyDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.scheduledQtyDataGridViewTextBoxColumn.Name = "scheduledQtyDataGridViewTextBoxColumn";
            this.scheduledQtyDataGridViewTextBoxColumn.Width = 154;
            // 
            // qtyDeliveredDataGridViewTextBoxColumn
            // 
            this.qtyDeliveredDataGridViewTextBoxColumn.DataPropertyName = "Qty_Delivered";
            this.qtyDeliveredDataGridViewTextBoxColumn.HeaderText = "Qty_Delivered";
            this.qtyDeliveredDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.qtyDeliveredDataGridViewTextBoxColumn.Name = "qtyDeliveredDataGridViewTextBoxColumn";
            this.qtyDeliveredDataGridViewTextBoxColumn.Width = 144;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 104;
            // 
            // pKeyDataGridViewTextBoxColumn
            // 
            this.pKeyDataGridViewTextBoxColumn.DataPropertyName = "PKey";
            this.pKeyDataGridViewTextBoxColumn.HeaderText = "PKey";
            this.pKeyDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pKeyDataGridViewTextBoxColumn.Name = "pKeyDataGridViewTextBoxColumn";
            this.pKeyDataGridViewTextBoxColumn.ReadOnly = true;
            this.pKeyDataGridViewTextBoxColumn.Width = 81;
            // 
            // includeValueDataGridViewTextBoxColumn
            // 
            this.includeValueDataGridViewTextBoxColumn.DataPropertyName = "IncludeValue";
            this.includeValueDataGridViewTextBoxColumn.HeaderText = "IncludeValue";
            this.includeValueDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.includeValueDataGridViewTextBoxColumn.Name = "includeValueDataGridViewTextBoxColumn";
            this.includeValueDataGridViewTextBoxColumn.Width = 138;
            // 
            // type3TableAdapter
            // 
            this.type3TableAdapter.ClearBeforeFill = true;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1477, 718);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.bindingNavigator1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form4";
            this.Text = "All Data";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.type3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.srgDataSet14)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private srgDataSet14 srgDataSet14;
        private System.Windows.Forms.BindingSource type3BindingSource;
        private srgDataSet14TableAdapters.type3TableAdapter type3TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchDocDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pOrgDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn docDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn siteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mdseCatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorArticleNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pOQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn netPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dCIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn delivDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statDelDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pstngDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn entryDteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn scheduledQtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDeliveredDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pKeyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn includeValueDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripLabel pOrgToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox pOrgToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel vendorToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox vendorToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel siteToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox siteToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
    }
}