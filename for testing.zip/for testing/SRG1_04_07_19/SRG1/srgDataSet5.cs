﻿namespace SRG1
{


    partial class srgDataSet5
    {
    }
}

