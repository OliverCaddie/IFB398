﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace SRG1
{
    public partial class Form2 : Form
    {
        public static Form2 Form2Instance;

        SqlConnection cnn = new SqlConnection(@"Data Source=localhost;Initial Catalog=srg;Integrated Security=True");
        SqlDataAdapter adapter;
        SqlCommandBuilder cmdbl;
        DataSet ds;
    //    static bool formOpened = false;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            textBox1.Text = Form1.SetDIF;
            textBox2.Text = Form1.SetDOT;
            label9.Text = Form1.SetBrand;
            label10.Text = Form1.SetTP;
            label11.Text = Form1.SetDC;
            label5.Text = Form1.SetSD;
            label6.Text = Form1.SetED;
            label8.Text = Form1.SetCat;
            label15.Text = Form1.SetSCat;
            label18.Text = Form1.SetArt;
            label20.Text = Form1.SetPO;
            label22.Text = Form1.SetPurchOrg;

           // if (!formOpened)
           //     formOpened = true;
           // else
             //   this.Dispose();


            try
            { 
                cnn.Open();
                String sql;
                
                sql = "Select * from type3 WHERE Doc__Date >= '" + label5.Text + "' AND Doc__Date < '" + label6.Text + "'";

                sql += label9.Text != null && label9.Text != "" ? " AND POrg = '" + label9.Text + "'" : "";
                sql += label10.Text != null && label10.Text != "" ? " AND Vendor = '" + label10.Text + "'" : "";
                sql += label11.Text != null && label11.Text != "" ? " AND Site = '" + label11.Text + "'" : "";
                sql += label8.Text != null && label8.Text != "" ? " AND Mdse_Cat_ = '" + label8.Text + "'" : "";
                sql += label15.Text != null && label15.Text != "" ? " AND Vendor_Article_Number = '" + label15.Text + "'" : "";
                sql += label18.Text != null && label18.Text != "" ? " AND Article = '" + label18.Text + "'" : "";
                sql += label20.Text != null && label20.Text != "" ? " AND Purch_Doc_ = '" + label20.Text + "'" : "";

                adapter = new SqlDataAdapter(sql, cnn);
                ds = new System.Data.DataSet();
                adapter.Fill(ds, "Query");
                dataGridView2.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            foreach (DataGridViewColumn dc in dataGridView2.Columns)
            {
                if (dc.Index.Equals(21))
                {
                    dc.ReadOnly = false;
                }
                else
                {
                    dc.ReadOnly = true;
                }
            }
            cnn.Close();
        }

        //   private void Button2_Click(object sender, EventArgs e)
        //    {
        //       Close();
        //   }
       // private void Form2_FormClosing(object sender, FormClosingEventArgs e)
       // {
       //     if (formOpened)
       //         formOpened = false;
       // }

        private void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                cmdbl = new SqlCommandBuilder(adapter);
                adapter.Update(ds, "Query");
                MessageBox.Show("Information Updated", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);

                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void Button4_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel Documents (*.xls)|*.xls";
            sfd.FileName = ".xls";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Copy DataGridView results to clipboard
                    copyAlltoClipboard();

                    object misValue = System.Reflection.Missing.Value;
                    Excel.Application xlexcel = new Excel.Application();

                    xlexcel.DisplayAlerts = false; // Without this it will give two confirm overwrite prompts
                    Excel.Workbook xlWorkBook = xlexcel.Workbooks.Add(misValue);
                    Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                    // Format column D as text before pasting results, this was required for the data
                    //  Excel.Range rng = xlWorkSheet.get_Range("D:D").Cells;
                    //  rng.NumberFormat = "@";

                    // Paste clipboard results to worksheet range
                    Excel.Range CR = (Excel.Range)xlWorkSheet.Cells[2, 1];
                    CR.Select();
                    xlWorkSheet.PasteSpecial(CR, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, true);

                    // Delete blank column A and select cell A1
                    Excel.Range delRng = xlWorkSheet.get_Range("A:A").Cells;
                    delRng.Delete(Type.Missing);
                    xlWorkSheet.get_Range("A1").Select();

                    // Save the excel file under the captured location from the SaveFileDialog
                    xlWorkBook.SaveAs(sfd.FileName, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                    xlexcel.DisplayAlerts = true;
                    xlWorkBook.Close(true, misValue, misValue);
                    xlexcel.Quit();

                    releaseObject(xlWorkSheet);
                    releaseObject(xlWorkBook);
                    releaseObject(xlexcel);

                    // Clear Clipboard and DataGridView selection
                    Clipboard.Clear();
                    dataGridView2.ClearSelection();

                    // Open the newly saved excel file
                    //  if (File.Exists(sfd.FileName))
                    System.Diagnostics.Process.Start(sfd.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Close();
                }
            }
        }

        private void copyAlltoClipboard()
        {   
            dataGridView2.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridView2.MultiSelect = true;
            dataGridView2.SelectAll();
            dataGridView2.Columns.RemoveAt(7);
            dataGridView2.Columns.RemoveAt(10);
            dataGridView2.Columns.RemoveAt(10);
            dataGridView2.Columns.RemoveAt(17);
            dataGridView2.Columns.RemoveAt(17);
            DataObject dataObj = dataGridView2.GetClipboardContent();
            if (dataObj != null)
                Clipboard.SetDataObject(dataObj);
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occurred while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        
    }
}
    

