﻿namespace SRG1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.purchDocDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pOrgDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mdseCatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorArticleNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pOQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.netPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dCIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.delivDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statDelDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pstngDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entryDteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scheduledQtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDeliveredDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.type3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.srgDataSet9 = new SRG1.srgDataSet9();
            this.select_DataToolStrip = new System.Windows.Forms.ToolStrip();
            this.brandToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.brandToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.tradePartnerToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.tradePartnerToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.distrCentreToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.distrCentreToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.select_DataToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.type3TableAdapter = new SRG1.srgDataSet9TableAdapters.type3TableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.purchDocDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pOrgDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docDateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siteDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articleDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mdseCatDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorArticleNumberDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pOQuantityDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.netPriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dCIDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.delivDateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statDelDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pstngDateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entryDteDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scheduledQtyDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDeliveredDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.type3BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.srgDataSet10 = new SRG1.srgDataSet10();
            this.select_RowToolStrip = new System.Windows.Forms.ToolStrip();
            this.brandToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.brandToolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.trade_PartnerToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.trade_PartnerToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.distr_CentreToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.distr_CentreToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.select_RowToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.type3TableAdapter1 = new SRG1.srgDataSet10TableAdapters.type3TableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.srgDataSet11 = new SRG1.srgDataSet11();
            this.dIFBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dIFTableAdapter = new SRG1.srgDataSet11TableAdapters.DIFTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.type3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.srgDataSet9)).BeginInit();
            this.select_DataToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.type3BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.srgDataSet10)).BeginInit();
            this.select_RowToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.srgDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dIFBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.purchDocDataGridViewTextBoxColumn,
            this.pOrgDataGridViewTextBoxColumn,
            this.docDateDataGridViewTextBoxColumn,
            this.vendorDataGridViewTextBoxColumn,
            this.siteDataGridViewTextBoxColumn,
            this.itemDataGridViewTextBoxColumn,
            this.articleDataGridViewTextBoxColumn,
            this.mdseCatDataGridViewTextBoxColumn,
            this.vendorArticleNumberDataGridViewTextBoxColumn,
            this.pOQuantityDataGridViewTextBoxColumn,
            this.netPriceDataGridViewTextBoxColumn,
            this.dDataGridViewTextBoxColumn,
            this.dCIDataGridViewTextBoxColumn,
            this.delivDateDataGridViewTextBoxColumn,
            this.statDelDDataGridViewTextBoxColumn,
            this.pstngDateDataGridViewTextBoxColumn,
            this.entryDteDataGridViewTextBoxColumn,
            this.scheduledQtyDataGridViewTextBoxColumn,
            this.qtyDeliveredDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.type3BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(45, 103);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.Size = new System.Drawing.Size(1800, 426);
            this.dataGridView1.TabIndex = 0;
            // 
            // purchDocDataGridViewTextBoxColumn
            // 
            this.purchDocDataGridViewTextBoxColumn.DataPropertyName = "Purch_Doc_";
            this.purchDocDataGridViewTextBoxColumn.HeaderText = "Purch_Doc_";
            this.purchDocDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.purchDocDataGridViewTextBoxColumn.Name = "purchDocDataGridViewTextBoxColumn";
            this.purchDocDataGridViewTextBoxColumn.Width = 133;
            // 
            // pOrgDataGridViewTextBoxColumn
            // 
            this.pOrgDataGridViewTextBoxColumn.DataPropertyName = "POrg";
            this.pOrgDataGridViewTextBoxColumn.HeaderText = "POrg";
            this.pOrgDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pOrgDataGridViewTextBoxColumn.Name = "pOrgDataGridViewTextBoxColumn";
            this.pOrgDataGridViewTextBoxColumn.Width = 81;
            // 
            // docDateDataGridViewTextBoxColumn
            // 
            this.docDateDataGridViewTextBoxColumn.DataPropertyName = "Doc__Date";
            this.docDateDataGridViewTextBoxColumn.HeaderText = "Doc__Date";
            this.docDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.docDateDataGridViewTextBoxColumn.Name = "docDateDataGridViewTextBoxColumn";
            this.docDateDataGridViewTextBoxColumn.Width = 127;
            // 
            // vendorDataGridViewTextBoxColumn
            // 
            this.vendorDataGridViewTextBoxColumn.DataPropertyName = "Vendor";
            this.vendorDataGridViewTextBoxColumn.HeaderText = "Vendor";
            this.vendorDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vendorDataGridViewTextBoxColumn.Name = "vendorDataGridViewTextBoxColumn";
            this.vendorDataGridViewTextBoxColumn.Width = 97;
            // 
            // siteDataGridViewTextBoxColumn
            // 
            this.siteDataGridViewTextBoxColumn.DataPropertyName = "Site";
            this.siteDataGridViewTextBoxColumn.HeaderText = "Site";
            this.siteDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.siteDataGridViewTextBoxColumn.Name = "siteDataGridViewTextBoxColumn";
            this.siteDataGridViewTextBoxColumn.Width = 73;
            // 
            // itemDataGridViewTextBoxColumn
            // 
            this.itemDataGridViewTextBoxColumn.DataPropertyName = "Item";
            this.itemDataGridViewTextBoxColumn.HeaderText = "Item";
            this.itemDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.itemDataGridViewTextBoxColumn.Name = "itemDataGridViewTextBoxColumn";
            this.itemDataGridViewTextBoxColumn.Width = 77;
            // 
            // articleDataGridViewTextBoxColumn
            // 
            this.articleDataGridViewTextBoxColumn.DataPropertyName = "Article";
            this.articleDataGridViewTextBoxColumn.HeaderText = "Article";
            this.articleDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.articleDataGridViewTextBoxColumn.Name = "articleDataGridViewTextBoxColumn";
            this.articleDataGridViewTextBoxColumn.Width = 89;
            // 
            // mdseCatDataGridViewTextBoxColumn
            // 
            this.mdseCatDataGridViewTextBoxColumn.DataPropertyName = "Mdse_Cat_";
            this.mdseCatDataGridViewTextBoxColumn.HeaderText = "Mdse_Cat_";
            this.mdseCatDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.mdseCatDataGridViewTextBoxColumn.Name = "mdseCatDataGridViewTextBoxColumn";
            this.mdseCatDataGridViewTextBoxColumn.Width = 127;
            // 
            // vendorArticleNumberDataGridViewTextBoxColumn
            // 
            this.vendorArticleNumberDataGridViewTextBoxColumn.DataPropertyName = "Vendor_Article_Number";
            this.vendorArticleNumberDataGridViewTextBoxColumn.HeaderText = "Vendor_Article_Number";
            this.vendorArticleNumberDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vendorArticleNumberDataGridViewTextBoxColumn.Name = "vendorArticleNumberDataGridViewTextBoxColumn";
            this.vendorArticleNumberDataGridViewTextBoxColumn.Width = 215;
            // 
            // pOQuantityDataGridViewTextBoxColumn
            // 
            this.pOQuantityDataGridViewTextBoxColumn.DataPropertyName = "PO_Quantity";
            this.pOQuantityDataGridViewTextBoxColumn.HeaderText = "PO_Quantity";
            this.pOQuantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pOQuantityDataGridViewTextBoxColumn.Name = "pOQuantityDataGridViewTextBoxColumn";
            this.pOQuantityDataGridViewTextBoxColumn.Width = 135;
            // 
            // netPriceDataGridViewTextBoxColumn
            // 
            this.netPriceDataGridViewTextBoxColumn.DataPropertyName = "Net_Price";
            this.netPriceDataGridViewTextBoxColumn.HeaderText = "Net_Price";
            this.netPriceDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.netPriceDataGridViewTextBoxColumn.Name = "netPriceDataGridViewTextBoxColumn";
            this.netPriceDataGridViewTextBoxColumn.Width = 114;
            // 
            // dDataGridViewTextBoxColumn
            // 
            this.dDataGridViewTextBoxColumn.DataPropertyName = "D";
            this.dDataGridViewTextBoxColumn.HeaderText = "D";
            this.dDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dDataGridViewTextBoxColumn.Name = "dDataGridViewTextBoxColumn";
            this.dDataGridViewTextBoxColumn.Width = 57;
            // 
            // dCIDataGridViewTextBoxColumn
            // 
            this.dCIDataGridViewTextBoxColumn.DataPropertyName = "DCI";
            this.dCIDataGridViewTextBoxColumn.HeaderText = "DCI";
            this.dCIDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dCIDataGridViewTextBoxColumn.Name = "dCIDataGridViewTextBoxColumn";
            this.dCIDataGridViewTextBoxColumn.Width = 73;
            // 
            // delivDateDataGridViewTextBoxColumn
            // 
            this.delivDateDataGridViewTextBoxColumn.DataPropertyName = "Deliv__Date";
            this.delivDateDataGridViewTextBoxColumn.HeaderText = "Deliv__Date";
            this.delivDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.delivDateDataGridViewTextBoxColumn.Name = "delivDateDataGridViewTextBoxColumn";
            this.delivDateDataGridViewTextBoxColumn.Width = 132;
            // 
            // statDelDDataGridViewTextBoxColumn
            // 
            this.statDelDDataGridViewTextBoxColumn.DataPropertyName = "StatDelD";
            this.statDelDDataGridViewTextBoxColumn.HeaderText = "StatDelD";
            this.statDelDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statDelDDataGridViewTextBoxColumn.Name = "statDelDDataGridViewTextBoxColumn";
            this.statDelDDataGridViewTextBoxColumn.Width = 111;
            // 
            // pstngDateDataGridViewTextBoxColumn
            // 
            this.pstngDateDataGridViewTextBoxColumn.DataPropertyName = "Pstng_Date";
            this.pstngDateDataGridViewTextBoxColumn.HeaderText = "Pstng_Date";
            this.pstngDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pstngDateDataGridViewTextBoxColumn.Name = "pstngDateDataGridViewTextBoxColumn";
            this.pstngDateDataGridViewTextBoxColumn.Width = 130;
            // 
            // entryDteDataGridViewTextBoxColumn
            // 
            this.entryDteDataGridViewTextBoxColumn.DataPropertyName = "Entry_Dte";
            this.entryDteDataGridViewTextBoxColumn.HeaderText = "Entry_Dte";
            this.entryDteDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.entryDteDataGridViewTextBoxColumn.Name = "entryDteDataGridViewTextBoxColumn";
            this.entryDteDataGridViewTextBoxColumn.Width = 117;
            // 
            // scheduledQtyDataGridViewTextBoxColumn
            // 
            this.scheduledQtyDataGridViewTextBoxColumn.DataPropertyName = "Scheduled_Qty";
            this.scheduledQtyDataGridViewTextBoxColumn.HeaderText = "Scheduled_Qty";
            this.scheduledQtyDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.scheduledQtyDataGridViewTextBoxColumn.Name = "scheduledQtyDataGridViewTextBoxColumn";
            this.scheduledQtyDataGridViewTextBoxColumn.Width = 154;
            // 
            // qtyDeliveredDataGridViewTextBoxColumn
            // 
            this.qtyDeliveredDataGridViewTextBoxColumn.DataPropertyName = "Qty_Delivered";
            this.qtyDeliveredDataGridViewTextBoxColumn.HeaderText = "Qty_Delivered";
            this.qtyDeliveredDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.qtyDeliveredDataGridViewTextBoxColumn.Name = "qtyDeliveredDataGridViewTextBoxColumn";
            this.qtyDeliveredDataGridViewTextBoxColumn.Width = 144;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 104;
            // 
            // type3BindingSource
            // 
            this.type3BindingSource.DataMember = "type3";
            this.type3BindingSource.DataSource = this.srgDataSet9;
            // 
            // srgDataSet9
            // 
            this.srgDataSet9.DataSetName = "srgDataSet9";
            this.srgDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // select_DataToolStrip
            // 
            this.select_DataToolStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.select_DataToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.brandToolStripLabel,
            this.brandToolStripTextBox,
            this.tradePartnerToolStripLabel,
            this.tradePartnerToolStripTextBox,
            this.distrCentreToolStripLabel,
            this.distrCentreToolStripTextBox,
            this.select_DataToolStripButton});
            this.select_DataToolStrip.Location = new System.Drawing.Point(0, 0);
            this.select_DataToolStrip.Name = "select_DataToolStrip";
            this.select_DataToolStrip.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.select_DataToolStrip.Size = new System.Drawing.Size(1587, 34);
            this.select_DataToolStrip.TabIndex = 1;
            this.select_DataToolStrip.Text = "select_DataToolStrip";
            
            // 
            // brandToolStripLabel
            // 
            this.brandToolStripLabel.Name = "brandToolStripLabel";
            this.brandToolStripLabel.Size = new System.Drawing.Size(62, 29);
            this.brandToolStripLabel.Text = "Brand:";
            // 
            // brandToolStripTextBox
            // 
            this.brandToolStripTextBox.Name = "brandToolStripTextBox";
            this.brandToolStripTextBox.Size = new System.Drawing.Size(148, 34);
            // 
            // tradePartnerToolStripLabel
            // 
            this.tradePartnerToolStripLabel.Name = "tradePartnerToolStripLabel";
            this.tradePartnerToolStripLabel.Size = new System.Drawing.Size(113, 29);
            this.tradePartnerToolStripLabel.Text = "TradePartner:";
            // 
            // tradePartnerToolStripTextBox
            // 
            this.tradePartnerToolStripTextBox.Name = "tradePartnerToolStripTextBox";
            this.tradePartnerToolStripTextBox.Size = new System.Drawing.Size(148, 34);
            // 
            // distrCentreToolStripLabel
            // 
            this.distrCentreToolStripLabel.Name = "distrCentreToolStripLabel";
            this.distrCentreToolStripLabel.Size = new System.Drawing.Size(104, 29);
            this.distrCentreToolStripLabel.Text = "DistrCentre:";
            // 
            // distrCentreToolStripTextBox
            // 
            this.distrCentreToolStripTextBox.Name = "distrCentreToolStripTextBox";
            this.distrCentreToolStripTextBox.Size = new System.Drawing.Size(148, 34);
            // 
            // select_DataToolStripButton
            // 
            this.select_DataToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.select_DataToolStripButton.Name = "select_DataToolStripButton";
            this.select_DataToolStripButton.Size = new System.Drawing.Size(106, 29);
            this.select_DataToolStripButton.Text = "Select_Data";
            this.select_DataToolStripButton.Click += new System.EventHandler(this.select_DataToolStripButton_Click);
            // 
            // type3TableAdapter
            // 
            this.type3TableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.purchDocDataGridViewTextBoxColumn1,
            this.pOrgDataGridViewTextBoxColumn1,
            this.docDateDataGridViewTextBoxColumn1,
            this.vendorDataGridViewTextBoxColumn1,
            this.siteDataGridViewTextBoxColumn1,
            this.itemDataGridViewTextBoxColumn1,
            this.articleDataGridViewTextBoxColumn1,
            this.mdseCatDataGridViewTextBoxColumn1,
            this.vendorArticleNumberDataGridViewTextBoxColumn1,
            this.pOQuantityDataGridViewTextBoxColumn1,
            this.netPriceDataGridViewTextBoxColumn1,
            this.dDataGridViewTextBoxColumn1,
            this.dCIDataGridViewTextBoxColumn1,
            this.delivDateDataGridViewTextBoxColumn1,
            this.statDelDDataGridViewTextBoxColumn1,
            this.pstngDateDataGridViewTextBoxColumn1,
            this.entryDteDataGridViewTextBoxColumn1,
            this.scheduledQtyDataGridViewTextBoxColumn1,
            this.qtyDeliveredDataGridViewTextBoxColumn1,
            this.quantityDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.type3BindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(45, 635);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.Size = new System.Drawing.Size(1800, 349);
            this.dataGridView2.TabIndex = 2;
            // 
            // purchDocDataGridViewTextBoxColumn1
            // 
            this.purchDocDataGridViewTextBoxColumn1.DataPropertyName = "Purch_Doc_";
            this.purchDocDataGridViewTextBoxColumn1.HeaderText = "Purch_Doc_";
            this.purchDocDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.purchDocDataGridViewTextBoxColumn1.Name = "purchDocDataGridViewTextBoxColumn1";
            this.purchDocDataGridViewTextBoxColumn1.Width = 133;
            // 
            // pOrgDataGridViewTextBoxColumn1
            // 
            this.pOrgDataGridViewTextBoxColumn1.DataPropertyName = "POrg";
            this.pOrgDataGridViewTextBoxColumn1.HeaderText = "POrg";
            this.pOrgDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.pOrgDataGridViewTextBoxColumn1.Name = "pOrgDataGridViewTextBoxColumn1";
            this.pOrgDataGridViewTextBoxColumn1.Width = 81;
            // 
            // docDateDataGridViewTextBoxColumn1
            // 
            this.docDateDataGridViewTextBoxColumn1.DataPropertyName = "Doc__Date";
            this.docDateDataGridViewTextBoxColumn1.HeaderText = "Doc__Date";
            this.docDateDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.docDateDataGridViewTextBoxColumn1.Name = "docDateDataGridViewTextBoxColumn1";
            this.docDateDataGridViewTextBoxColumn1.Width = 127;
            // 
            // vendorDataGridViewTextBoxColumn1
            // 
            this.vendorDataGridViewTextBoxColumn1.DataPropertyName = "Vendor";
            this.vendorDataGridViewTextBoxColumn1.HeaderText = "Vendor";
            this.vendorDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.vendorDataGridViewTextBoxColumn1.Name = "vendorDataGridViewTextBoxColumn1";
            this.vendorDataGridViewTextBoxColumn1.Width = 97;
            // 
            // siteDataGridViewTextBoxColumn1
            // 
            this.siteDataGridViewTextBoxColumn1.DataPropertyName = "Site";
            this.siteDataGridViewTextBoxColumn1.HeaderText = "Site";
            this.siteDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.siteDataGridViewTextBoxColumn1.Name = "siteDataGridViewTextBoxColumn1";
            this.siteDataGridViewTextBoxColumn1.Width = 73;
            // 
            // itemDataGridViewTextBoxColumn1
            // 
            this.itemDataGridViewTextBoxColumn1.DataPropertyName = "Item";
            this.itemDataGridViewTextBoxColumn1.HeaderText = "Item";
            this.itemDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.itemDataGridViewTextBoxColumn1.Name = "itemDataGridViewTextBoxColumn1";
            this.itemDataGridViewTextBoxColumn1.Width = 77;
            // 
            // articleDataGridViewTextBoxColumn1
            // 
            this.articleDataGridViewTextBoxColumn1.DataPropertyName = "Article";
            this.articleDataGridViewTextBoxColumn1.HeaderText = "Article";
            this.articleDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.articleDataGridViewTextBoxColumn1.Name = "articleDataGridViewTextBoxColumn1";
            this.articleDataGridViewTextBoxColumn1.Width = 89;
            // 
            // mdseCatDataGridViewTextBoxColumn1
            // 
            this.mdseCatDataGridViewTextBoxColumn1.DataPropertyName = "Mdse_Cat_";
            this.mdseCatDataGridViewTextBoxColumn1.HeaderText = "Mdse_Cat_";
            this.mdseCatDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.mdseCatDataGridViewTextBoxColumn1.Name = "mdseCatDataGridViewTextBoxColumn1";
            this.mdseCatDataGridViewTextBoxColumn1.Width = 127;
            // 
            // vendorArticleNumberDataGridViewTextBoxColumn1
            // 
            this.vendorArticleNumberDataGridViewTextBoxColumn1.DataPropertyName = "Vendor_Article_Number";
            this.vendorArticleNumberDataGridViewTextBoxColumn1.HeaderText = "Vendor_Article_Number";
            this.vendorArticleNumberDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.vendorArticleNumberDataGridViewTextBoxColumn1.Name = "vendorArticleNumberDataGridViewTextBoxColumn1";
            this.vendorArticleNumberDataGridViewTextBoxColumn1.Width = 215;
            // 
            // pOQuantityDataGridViewTextBoxColumn1
            // 
            this.pOQuantityDataGridViewTextBoxColumn1.DataPropertyName = "PO_Quantity";
            this.pOQuantityDataGridViewTextBoxColumn1.HeaderText = "PO_Quantity";
            this.pOQuantityDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.pOQuantityDataGridViewTextBoxColumn1.Name = "pOQuantityDataGridViewTextBoxColumn1";
            this.pOQuantityDataGridViewTextBoxColumn1.Width = 135;
            // 
            // netPriceDataGridViewTextBoxColumn1
            // 
            this.netPriceDataGridViewTextBoxColumn1.DataPropertyName = "Net_Price";
            this.netPriceDataGridViewTextBoxColumn1.HeaderText = "Net_Price";
            this.netPriceDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.netPriceDataGridViewTextBoxColumn1.Name = "netPriceDataGridViewTextBoxColumn1";
            this.netPriceDataGridViewTextBoxColumn1.Width = 114;
            // 
            // dDataGridViewTextBoxColumn1
            // 
            this.dDataGridViewTextBoxColumn1.DataPropertyName = "D";
            this.dDataGridViewTextBoxColumn1.HeaderText = "D";
            this.dDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dDataGridViewTextBoxColumn1.Name = "dDataGridViewTextBoxColumn1";
            this.dDataGridViewTextBoxColumn1.Width = 57;
            // 
            // dCIDataGridViewTextBoxColumn1
            // 
            this.dCIDataGridViewTextBoxColumn1.DataPropertyName = "DCI";
            this.dCIDataGridViewTextBoxColumn1.HeaderText = "DCI";
            this.dCIDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dCIDataGridViewTextBoxColumn1.Name = "dCIDataGridViewTextBoxColumn1";
            this.dCIDataGridViewTextBoxColumn1.Width = 73;
            // 
            // delivDateDataGridViewTextBoxColumn1
            // 
            this.delivDateDataGridViewTextBoxColumn1.DataPropertyName = "Deliv__Date";
            this.delivDateDataGridViewTextBoxColumn1.HeaderText = "Deliv__Date";
            this.delivDateDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.delivDateDataGridViewTextBoxColumn1.Name = "delivDateDataGridViewTextBoxColumn1";
            this.delivDateDataGridViewTextBoxColumn1.Width = 132;
            // 
            // statDelDDataGridViewTextBoxColumn1
            // 
            this.statDelDDataGridViewTextBoxColumn1.DataPropertyName = "StatDelD";
            this.statDelDDataGridViewTextBoxColumn1.HeaderText = "StatDelD";
            this.statDelDDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.statDelDDataGridViewTextBoxColumn1.Name = "statDelDDataGridViewTextBoxColumn1";
            this.statDelDDataGridViewTextBoxColumn1.Width = 111;
            // 
            // pstngDateDataGridViewTextBoxColumn1
            // 
            this.pstngDateDataGridViewTextBoxColumn1.DataPropertyName = "Pstng_Date";
            this.pstngDateDataGridViewTextBoxColumn1.HeaderText = "Pstng_Date";
            this.pstngDateDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.pstngDateDataGridViewTextBoxColumn1.Name = "pstngDateDataGridViewTextBoxColumn1";
            this.pstngDateDataGridViewTextBoxColumn1.Width = 130;
            // 
            // entryDteDataGridViewTextBoxColumn1
            // 
            this.entryDteDataGridViewTextBoxColumn1.DataPropertyName = "Entry_Dte";
            this.entryDteDataGridViewTextBoxColumn1.HeaderText = "Entry_Dte";
            this.entryDteDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.entryDteDataGridViewTextBoxColumn1.Name = "entryDteDataGridViewTextBoxColumn1";
            this.entryDteDataGridViewTextBoxColumn1.Width = 117;
            // 
            // scheduledQtyDataGridViewTextBoxColumn1
            // 
            this.scheduledQtyDataGridViewTextBoxColumn1.DataPropertyName = "Scheduled_Qty";
            this.scheduledQtyDataGridViewTextBoxColumn1.HeaderText = "Scheduled_Qty";
            this.scheduledQtyDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.scheduledQtyDataGridViewTextBoxColumn1.Name = "scheduledQtyDataGridViewTextBoxColumn1";
            this.scheduledQtyDataGridViewTextBoxColumn1.Width = 154;
            // 
            // qtyDeliveredDataGridViewTextBoxColumn1
            // 
            this.qtyDeliveredDataGridViewTextBoxColumn1.DataPropertyName = "Qty_Delivered";
            this.qtyDeliveredDataGridViewTextBoxColumn1.HeaderText = "Qty_Delivered";
            this.qtyDeliveredDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.qtyDeliveredDataGridViewTextBoxColumn1.Name = "qtyDeliveredDataGridViewTextBoxColumn1";
            this.qtyDeliveredDataGridViewTextBoxColumn1.Width = 144;
            // 
            // quantityDataGridViewTextBoxColumn1
            // 
            this.quantityDataGridViewTextBoxColumn1.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn1.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.quantityDataGridViewTextBoxColumn1.Name = "quantityDataGridViewTextBoxColumn1";
            this.quantityDataGridViewTextBoxColumn1.Width = 104;
            // 
            // type3BindingSource1
            // 
            this.type3BindingSource1.DataMember = "type3";
            this.type3BindingSource1.DataSource = this.srgDataSet10;
            // 
            // srgDataSet10
            // 
            this.srgDataSet10.DataSetName = "srgDataSet10";
            this.srgDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // select_RowToolStrip
            // 
            this.select_RowToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.select_RowToolStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.select_RowToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.brandToolStripLabel1,
            this.brandToolStripTextBox1,
            this.trade_PartnerToolStripLabel,
            this.trade_PartnerToolStripTextBox,
            this.distr_CentreToolStripLabel,
            this.distr_CentreToolStripTextBox,
            this.select_RowToolStripButton});
            this.select_RowToolStrip.Location = new System.Drawing.Point(14, 563);
            this.select_RowToolStrip.Name = "select_RowToolStrip";
            this.select_RowToolStrip.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.select_RowToolStrip.Size = new System.Drawing.Size(791, 34);
            this.select_RowToolStrip.TabIndex = 3;
            this.select_RowToolStrip.Text = "select_RowToolStrip";
            // 
            // brandToolStripLabel1
            // 
            this.brandToolStripLabel1.Name = "brandToolStripLabel1";
            this.brandToolStripLabel1.Size = new System.Drawing.Size(62, 29);
            this.brandToolStripLabel1.Text = "Brand:";
            // 
            // brandToolStripTextBox1
            // 
            this.brandToolStripTextBox1.Name = "brandToolStripTextBox1";
            this.brandToolStripTextBox1.Size = new System.Drawing.Size(148, 34);
            // 
            // trade_PartnerToolStripLabel
            // 
            this.trade_PartnerToolStripLabel.Name = "trade_PartnerToolStripLabel";
            this.trade_PartnerToolStripLabel.Size = new System.Drawing.Size(120, 29);
            this.trade_PartnerToolStripLabel.Text = "Trade_Partner:";
            // 
            // trade_PartnerToolStripTextBox
            // 
            this.trade_PartnerToolStripTextBox.Name = "trade_PartnerToolStripTextBox";
            this.trade_PartnerToolStripTextBox.Size = new System.Drawing.Size(148, 34);
            // 
            // distr_CentreToolStripLabel
            // 
            this.distr_CentreToolStripLabel.Name = "distr_CentreToolStripLabel";
            this.distr_CentreToolStripLabel.Size = new System.Drawing.Size(111, 29);
            this.distr_CentreToolStripLabel.Text = "Distr_Centre:";
            // 
            // distr_CentreToolStripTextBox
            // 
            this.distr_CentreToolStripTextBox.Name = "distr_CentreToolStripTextBox";
            this.distr_CentreToolStripTextBox.Size = new System.Drawing.Size(68, 34);
            // 
            // select_RowToolStripButton
            // 
            this.select_RowToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.select_RowToolStripButton.Name = "select_RowToolStripButton";
            this.select_RowToolStripButton.Size = new System.Drawing.Size(103, 29);
            this.select_RowToolStripButton.Text = "Select_Row";
            this.select_RowToolStripButton.Click += new System.EventHandler(this.select_RowToolStripButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(263, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Please specify individual parameters";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 609);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(311, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Please select all the properties for the rows";
            // 
            // type3TableAdapter1
            // 
            this.type3TableAdapter1.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1331, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 48);
            this.button1.TabIndex = 6;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // srgDataSet11
            // 
            this.srgDataSet11.DataSetName = "srgDataSet11";
            this.srgDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dIFBindingSource
            // 
            this.dIFBindingSource.DataMember = "DIF";
            this.dIFBindingSource.DataSource = this.srgDataSet11;
            // 
            // dIFTableAdapter
            // 
            this.dIFTableAdapter.ClearBeforeFill = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1587, 934);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.select_RowToolStrip);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.select_DataToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form3";
            this.Text = "Data";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.type3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.srgDataSet9)).EndInit();
            this.select_DataToolStrip.ResumeLayout(false);
            this.select_DataToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.type3BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.srgDataSet10)).EndInit();
            this.select_RowToolStrip.ResumeLayout(false);
            this.select_RowToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.srgDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dIFBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private srgDataSet9 srgDataSet9;
        private System.Windows.Forms.BindingSource type3BindingSource;
        private srgDataSet9TableAdapters.type3TableAdapter type3TableAdapter;
        private System.Windows.Forms.ToolStrip select_DataToolStrip;
        private System.Windows.Forms.ToolStripLabel brandToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox brandToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel tradePartnerToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox tradePartnerToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel distrCentreToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox distrCentreToolStripTextBox;
        private System.Windows.Forms.ToolStripButton select_DataToolStripButton;
        private System.Windows.Forms.DataGridView dataGridView2;
        private srgDataSet10 srgDataSet10;
        private System.Windows.Forms.BindingSource type3BindingSource1;
        private srgDataSet10TableAdapters.type3TableAdapter type3TableAdapter1;
        private System.Windows.Forms.ToolStrip select_RowToolStrip;
        private System.Windows.Forms.ToolStripLabel brandToolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox brandToolStripTextBox1;
        private System.Windows.Forms.ToolStripLabel trade_PartnerToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox trade_PartnerToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel distr_CentreToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox distr_CentreToolStripTextBox;
        private System.Windows.Forms.ToolStripButton select_RowToolStripButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private srgDataSet11 srgDataSet11;
        private System.Windows.Forms.BindingSource dIFBindingSource;
        private srgDataSet11TableAdapters.DIFTableAdapter dIFTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchDocDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pOrgDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn docDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn siteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mdseCatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorArticleNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pOQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn netPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dCIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn delivDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statDelDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pstngDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn entryDteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn scheduledQtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDeliveredDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchDocDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pOrgDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn docDateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn siteDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn articleDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mdseCatDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorArticleNumberDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pOQuantityDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn netPriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dCIDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn delivDateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn statDelDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pstngDateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn entryDteDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn scheduledQtyDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDeliveredDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn1;
    }
}